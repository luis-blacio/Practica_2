/**
 * This package contains reusable domain classes.
 */
@NullMarked
package io.codecaribou.spark.base.domain;

import org.jspecify.annotations.NullMarked;
